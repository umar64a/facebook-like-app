import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Login from "./Components/Login";
import SignUp from "./Components/SignUp";
import Home from "./Components/Home";
import User from "./Components/User";
import Friends from "./Components/Friends";
import Groups from "./Components/Groups";
import UserProfile from "./Components/UserProfile";
import Videos from "./Components/Videos";
import UserGroup from "./Components/UserGroup";
import GroupDetails from "./Components/GroupDetails";
import Search from "./Components/Search";
import "./App.css";

function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/" element={<Login />}></Route>
        <Route path="/signup" element={<SignUp />}></Route>
        <Route path="/home" element={<Home />}></Route>
        <Route path="/user" element={<User />}></Route>
        <Route path="/friends" element={<Friends />}></Route>
        <Route path="/groups" element={<Groups />}></Route>
        <Route path="/userProfile/:id" element={<UserProfile />}></Route>
        <Route path="/videos" element={<Videos />}></Route>
        <Route path="/UserGroup" element={<UserGroup />}></Route>
        <Route path="/groupdetails" element={<GroupDetails />}></Route>
        <Route path="/search" element={<Search />}></Route>
      </Routes>
    </Router>
  );
}

export default App;
