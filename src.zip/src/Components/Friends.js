import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";
import { useNavigate } from "react-router-dom";

import "./Friends.css";

const defaultProfilePicture = "https://via.placeholder.com/150";

export default function Friends() {
  const [user, setUser] = useState({});
  const [friends, setFriends] = useState([]);
  const [friendRequests, setFriendRequests] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [activeTab, setActiveTab] = useState("allFriends");
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();
  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user")) || {};
    const storedFriends = JSON.parse(localStorage.getItem("friends")) || {};
    const storedRequests =
      JSON.parse(localStorage.getItem("friendRequests")) || [];
    const allStoredUsers = JSON.parse(localStorage.getItem("users")) || [];

    if (!storedUser.id) {
      storedUser.id = uuidv4();
      localStorage.setItem("user", JSON.stringify(storedUser));
    }
    setUser(storedUser);

    const userFriends = storedFriends[storedUser.id] || [];
    setFriends(userFriends);
    localStorage.setItem(
      "friends",
      JSON.stringify({ ...storedFriends, [storedUser.id]: userFriends })
    );
    setFriendRequests(storedRequests);

    const filteredUsers = allStoredUsers.filter((u) => u.id !== storedUser.id);
    setAllUsers(filteredUsers);
  }, []);

  const sendFriendRequest = (id) => {
    const selectedUser = allUsers.find((user) => user.id === id);
    const newRequest = {
      id: uuidv4(),
      senderId: user.id,
      senderName: `${user.firstName} ${user.lastName}`,
      senderProfilePicture: user.profilePicture || defaultProfilePicture,
      receiverId: selectedUser.id,
    };

    const updatedRequests = [...friendRequests, newRequest];
    setFriendRequests(updatedRequests);
    localStorage.setItem("friendRequests", JSON.stringify(updatedRequests));
  };

  const cancelFriendRequest = (id) => {
    const updatedRequests = friendRequests.filter(
      (request) => !(request.receiverId === id && request.senderId === user.id)
    );
    setFriendRequests(updatedRequests);
    localStorage.setItem("friendRequests", JSON.stringify(updatedRequests));
  };
  const acceptFriendRequest = (id) => {
    const selectedUser = allUsers.find((user) => user.id === id);
    if (!selectedUser) return;

    const updatedFriends = [
      ...friends,
      {
        id: selectedUser.id,
        firstName: selectedUser.firstName,
        lastName: selectedUser.lastName,
        profilePicture: selectedUser.profilePicture || defaultProfilePicture,
      },
    ];
    setFriends(updatedFriends);
    localStorage.setItem(
      "friends",
      JSON.stringify({
        ...JSON.parse(localStorage.getItem("friends") || "{}"),
        [user.id]: updatedFriends,
      })
    );

    const friendFriends =
      JSON.parse(localStorage.getItem("friends") || "{}")[selectedUser.id] ||
      [];
    const updatedFriendFriends = [
      ...friendFriends,
      {
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        profilePicture: user.profilePicture || defaultProfilePicture,
      },
    ];
    localStorage.setItem(
      "friends",
      JSON.stringify({
        ...JSON.parse(localStorage.getItem("friends") || "{}"),
        [selectedUser.id]: updatedFriendFriends,
      })
    );

    const updatedRequests = friendRequests.filter(
      (request) => request.senderId !== id || request.receiverId !== user.id
    );
    setFriendRequests(updatedRequests);
    localStorage.setItem("friendRequests", JSON.stringify(updatedRequests));

    const updatedUsers = allUsers.filter((user) => user.id !== selectedUser.id);
    setAllUsers(updatedUsers);
  };
  const rejectFriendRequest = (id) => {
    const updatedRequests = friendRequests.filter(
      (request) => request.senderId !== id || request.receiverId !== user.id
    );
    setFriendRequests(updatedRequests);
    localStorage.setItem("friendRequests", JSON.stringify(updatedRequests));
  };

  const handleSearch = (e) => {
    e.preventDefault();
    navigate(`/search?term=${encodeURIComponent(searchTerm)}`);
  };

  const renderContent = () => {
    switch (activeTab) {
      case "allFriends":
        return (
          <div className="recommendations">
            <h2>People You May Know</h2>
            {allUsers
              .filter(
                (currentUser) =>
                  currentUser.id !== user.id &&
                  !friends.some((friend) => friend.id === currentUser.id)
              )
              .map((currentUser) => (
                <div key={currentUser.id} className="recommendation">
                  <Link to={`/userProfile/${currentUser.id}`}>
                    <img
                      src={currentUser.profilePicture || defaultProfilePicture}
                      alt={currentUser.firstName}
                      className="recommendation-pic"
                    />
                    <span>
                      {currentUser.firstName} {currentUser.lastName}
                    </span>
                  </Link>
                  {friendRequests.some(
                    (req) =>
                      req.senderId === user.id &&
                      req.receiverId === currentUser.id
                  ) ? (
                    <button onClick={() => cancelFriendRequest(currentUser.id)}>
                      Cancel request
                    </button>
                  ) : (
                    <button onClick={() => sendFriendRequest(currentUser.id)}>
                      Add friend
                    </button>
                  )}
                </div>
              ))}
          </div>
        );
      case "friendRequests":
        return (
          <div className="friend-requests">
            {friendRequests.filter((request) => request.receiverId === user.id)
              .length === 0 ? (
              <p>No friend requests.</p>
            ) : (
              friendRequests
                .filter((request) => request.receiverId === user.id)
                .map((request) => (
                  <div key={request.id} className="friend-request">
                    <Link to={`/userProfile/${request.senderId}`}>
                      <img
                        src={request.senderProfilePicture}
                        alt="Profile"
                        className="friend-profile-pic"
                      />
                      <span>{request.senderName}</span>
                    </Link>
                    <button
                      onClick={() => acceptFriendRequest(request.senderId)}
                    >
                      Accept
                    </button>
                    <button
                      onClick={() => rejectFriendRequest(request.senderId)}
                    >
                      Reject
                    </button>
                  </div>
                ))
            )}
          </div>
        );
      case "yourFriends":
        return (
          <div className="friend-list">
            {friends.length === 0 ? (
              <p>No friends added yet.</p>
            ) : (
              friends.map((friend) => (
                <div key={friend.id} className="friend">
                  <Link to={`/userProfile/${friend.id}`}>
                    <img
                      src={friend.profilePicture || defaultProfilePicture}
                      alt="Profile"
                      className="friend-profile-pic"
                    />
                    <span>
                      {friend.firstName} {friend.lastName}
                    </span>
                  </Link>
                </div>
              ))
            )}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <>
      <div className="header">
        <i className="fab fa-facebook"></i>
        <form onSubmit={handleSearch}>
          <div className="search-container">
            <i className="fas fa-search search-icon"></i>
            <input
              type="search"
              className="search-bar"
              placeholder="Search Facebook"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </form>
        <div className="links">
          <Link className="nav-item" to="/home">
            <i className="i fa-solid fa-house"></i>
            <span className="tooltip-text">Home</span>
          </Link>
          <Link className="nav-item" to="/friends">
            <i className="i fa-solid fa-user-group"></i>
            <span className="tooltip-text">Friends</span>
          </Link>
          <Link className="nav-item" to="/videos">
            <i className="i fa-brands fa-youtube"></i>
            <span className="tooltip-text">Videos</span>
          </Link>
          <Link className="nav-item" to="/groups">
            <i className="i fa-solid fa-users"></i>
            <span className="grp-txt tooltip-text">Groups</span>
          </Link>
        </div>
        <div className="user-info">
          <Link to="/user" id="link">
            <img
              src={user.profilePicture || defaultProfilePicture}
              alt="Profile"
              className="profile-pic"
            />
          </Link>
          <span className="user-name">
            {user.firstName} {user.lastName}
          </span>
        </div>
      </div>
      <div className="friends-page">
        <div className="tab-btns">
          <button
            className={`tab ${activeTab === "allFriends" && "active"}`}
            onClick={() => setActiveTab("allFriends")}
          >
            All Friends
          </button>
          <button
            className={`tab ${activeTab === "friendRequests" && "active"}`}
            onClick={() => setActiveTab("friendRequests")}
          >
            Friend Requests
          </button>
          <button
            className={`tab ${activeTab === "yourFriends" && "active"}`}
            onClick={() => setActiveTab("yourFriends")}
          >
            Your Friends
          </button>
        </div>
        <div className="Tabs-content">{renderContent()}</div>
      </div>
    </>
  );
}
