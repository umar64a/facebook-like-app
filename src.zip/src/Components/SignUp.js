import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";
import "./SignUp.css";

export default function SignUp() {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [birthday, setBirthday] = useState("");
  const [gender, setGender] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate();

  const handleSignUp = (e) => {
    e.preventDefault();

    if (
      !firstName ||
      !lastName ||
      !email ||
      !password ||
      !birthday ||
      !gender
    ) {
      setErrorMessage("All fields are required.");
      return;
    }

    if (password.length !== 8) {
      setErrorMessage("Password must be exactly 8 characters long.");
      return;
    }

    const newUser = {
      id: uuidv4(),
      firstName,
      lastName,
      email,
      password,
      birthday,
      gender,
    };

    const existingUsers = JSON.parse(localStorage.getItem("users")) || [];
    const isExistingUser = existingUsers.some((user) => user.email === email);

    if (isExistingUser) {
      setErrorMessage(
        "This email is already registered. Please use a different email."
      );
      return;
    }

    const updatedUsers = [...existingUsers, newUser];
    localStorage.setItem("users", JSON.stringify(updatedUsers));
    localStorage.setItem("user", JSON.stringify(newUser));
    navigate("/home");
  };

  return (
    <div className="singup-form">
      <h2>Sign Up</h2>
      <p>It's quick and easy.</p>
      <hr />
      <div className="text">
        <input
          type="text"
          className="input"
          placeholder="First name"
          value={firstName}
          onChange={(e) => setFirstName(e.target.value)}
          required
        />
        <input
          type="text"
          className="input"
          placeholder="Last name"
          value={lastName}
          onChange={(e) => setLastName(e.target.value)}
          required
        />
        <input
          type="email"
          className="input"
          placeholder="Email address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="password"
          className="input"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <span className="text">BirthDay</span>
        <input
          type="date"
          className="input"
          value={birthday}
          onChange={(e) => setBirthday(e.target.value)}
          required
        />
        <select
          className="input"
          value={gender}
          onChange={(e) => setGender(e.target.value)}
          required
        >
          <option value="">Select Gender</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
          <option value="other">Other</option>
        </select>
      </div>
      {errorMessage && <div className="error">{errorMessage}</div>}

      <p>
        People who use our service may have uploaded your contact information to
        Facebook.<Link href="#!"> Learn more.</Link>
      </p>
      <p>
        By clicking Sign Up, you agree to our<Link href="#!"> Terms</Link>,
        <Link href="#!"> Privacy Policy </Link>and
        <Link href="#!"> Cookies Policy.</Link>
        You may receive SMS notifications from us and can opt out at any time.
      </p>
      <button className="signup" type="submit" onClick={handleSignUp}>
        Sign Up
      </button>
    </div>
  );
}
