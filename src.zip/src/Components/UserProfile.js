import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";
import { useNavigate } from "react-router-dom";

import "./UserProfile.css";

const defaultProfilePicture = "https://via.placeholder.com/150";
const defaultCoverPhoto = "https://via.placeholder.com/800x200";

export default function UserProfile() {
  const { id } = useParams();
  const [selectedUser, setSelectedUser] = useState(null);
  const [posts, setPosts] = useState([]);
  const [photos, setPhotos] = useState([]);
  const [friends, setFriends] = useState([]);
  const [activeTab, setActiveTab] = useState("posts");
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [friendRequests, setFriendRequests] = useState([]);
  const [isRequestSent, setIsRequestSent] = useState(false);
  const [isFriend, setIsFriend] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();
  useEffect(() => {
    const allUsers = JSON.parse(localStorage.getItem("users")) || [];
    const selectedUser = allUsers.find((user) => user.id === id);
    const storedUser = JSON.parse(localStorage.getItem("user")) || {};
    setLoggedInUser(storedUser);
    setSelectedUser(selectedUser);

    if (selectedUser) {
      const allPosts = JSON.parse(localStorage.getItem("posts")) || [];
      const userPosts = allPosts.filter(
        (post) =>
          post.authorEmail === selectedUser.email &&
          !(post.deletedByUser || []).includes(selectedUser.email)
      );
      setPosts(userPosts);

      const allPhotos = JSON.parse(localStorage.getItem("photos")) || [];
      const userPhotos = allPhotos.filter(
        (photo) => photo.authorEmail === selectedUser.email
      );
      setPhotos(userPhotos);

      const allFriends = JSON.parse(localStorage.getItem("friends")) || {};
      const selectedUserFriends = allFriends[selectedUser.id] || [];
      setFriends(selectedUserFriends);

      const isFriend = selectedUserFriends.some(
        (friend) => friend.id === storedUser.id
      );
      setIsFriend(isFriend);

      const storedRequests =
        JSON.parse(localStorage.getItem("friendRequests")) || [];
      setFriendRequests(storedRequests);

      const isSent = storedRequests.some(
        (request) =>
          request.senderId === storedUser.id &&
          request.receiverId === selectedUser.id
      );
      setIsRequestSent(isSent);
    }
  }, [id]);

  const handleLikeToggle = (postId) => {
    const updatedPosts = posts.map((post) => {
      if (post.id === postId) {
        const likesArray = Array.isArray(post.likes) ? post.likes : [];
        const alreadyLiked = likesArray.includes(loggedInUser.email);

        return {
          ...post,
          likes: alreadyLiked
            ? likesArray.filter((email) => email !== loggedInUser.email)
            : [...likesArray, loggedInUser.email],
        };
      }
      return post;
    });

    setPosts(updatedPosts);
    localStorage.setItem("posts", JSON.stringify(updatedPosts));
  };

  const handleAddFriend = (friend) => {
    const isRequestAlreadySent = friendRequests.some(
      (request) =>
        request.senderId === loggedInUser.id && request.receiverId === friend.id
    );

    if (isRequestAlreadySent) {
      const updatedRequests = friendRequests.filter(
        (request) =>
          !(
            request.senderId === loggedInUser.id &&
            request.receiverId === friend.id
          )
      );
      setFriendRequests(updatedRequests);
      localStorage.setItem("friendRequests", JSON.stringify(updatedRequests));
      setIsRequestSent(false);
    } else {
      const newRequest = {
        id: uuidv4(),
        senderId: loggedInUser.id,
        senderName: `${loggedInUser.firstName} ${loggedInUser.lastName}`,
        senderProfilePicture:
          loggedInUser.profilePicture || defaultProfilePicture,
        receiverId: friend.id,
      };

      const updatedRequests = [...friendRequests, newRequest];
      setFriendRequests(updatedRequests);
      localStorage.setItem("friendRequests", JSON.stringify(updatedRequests));
      setIsRequestSent(true);
    }

    const updatedFriends = friends.map((f) => {
      if (f.id === friend.id) {
        return { ...f, isRequestSent: !isRequestAlreadySent };
      }
      return f;
    });
    setFriends(updatedFriends);
  };

  const renderButtons = (friend) => {
    if (isFriend) {
      return (
        <button className="friends-btn">
          <i className="fa-solid fa-user-check"></i> Friends
        </button>
      );
    } else {
      return (
        <button className="addFriend" onClick={() => handleAddFriend(friend)}>
          <i
            className={`fa-solid ${
              isRequestSent ? "fa-user-xmark" : "fa-user-plus"
            }`}
          ></i>
          {isRequestSent ? "Cancel request" : "Add friend"}
        </button>
      );
    }
  };
  const handleSearch = (e) => {
    e.preventDefault();
    navigate(`/search?term=${encodeURIComponent(searchTerm)}`);
  };
  const renderTabContent = () => {
    switch (activeTab) {
      case "posts":
        return (
          <div className="posts">
            {posts.length > 0 ? (
              posts.map((post) => (
                <div key={post.id} className="post">
                  <div className="post-header">
                    <img
                      src={post.profilePicture || defaultProfilePicture}
                      alt="Author"
                      className="profile-picture"
                    />
                    <span className="span">{post.author}</span>
                  </div>
                  <p className="content">{post.content}</p>
                  {post.profileImage && (
                    <div className="post-media-container">
                      <img
                        src={post.profileImage}
                        alt="Post"
                        className="post-media post-profile"
                      />
                    </div>
                  )}
                  {post.image && (
                    <div className="post-media-container">
                      <img src={post.image} alt="Post" className="post-media" />
                    </div>
                  )}
                  {post.media && (
                    <div className="post-media-container">
                      {post.media.startsWith("data:image") ? (
                        <img
                          src={post.media}
                          alt="Post media"
                          className="post-media"
                        />
                      ) : (
                        <video
                          controls
                          src={post.media}
                          alt="Post media"
                          className="post-media"
                        ></video>
                      )}
                    </div>
                  )}
                  <div className="post-actions">
                    <hr />
                    <button
                      onClick={() => handleLikeToggle(post.id)}
                      className={
                        Array.isArray(post.likes) &&
                        post.likes.includes(loggedInUser.email)
                          ? "liked"
                          : ""
                      }
                    >
                      <i className="fa-solid fa-thumbs-up"></i>
                      {Array.isArray(post.likes) &&
                      post.likes.includes(loggedInUser.email)
                        ? "Unlike"
                        : "Like"}{" "}
                      {Array.isArray(post.likes) ? post.likes.length : 0}
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <p>No posts available.</p>
            )}
          </div>
        );

      case "about":
        return (
          <div className="about">
            <h2>About</h2>
            <p>
              <strong>Workplace:</strong>{" "}
              {selectedUser?.workplace || "Not Available"}
            </p>
            <p>
              <strong>High School:</strong>{" "}
              {selectedUser?.highSchool || "Not Available"}
            </p>
            <p>
              <strong>College:</strong>{" "}
              {selectedUser?.college || "Not Available"}
            </p>
            <p>
              <strong>City:</strong> {selectedUser?.city || "Not Available"}
            </p>
            <p>
              <strong>Hometown:</strong>{" "}
              {selectedUser?.hometown || "Not Available"}
            </p>
            <p>
              <strong>Relation:</strong>{" "}
              {selectedUser?.relation || "Not Available"}
            </p>
            <p>
              <strong>Phone:</strong> {selectedUser?.phone || "Not Available"}
            </p>
          </div>
        );

      case "friends":
        return (
          <div className="userFriend-list">
            <h2>Friends</h2>
            {friends.length === 0 ? (
              <p>No friends added yet.</p>
            ) : (
              friends.map((friend) => (
                <div key={friend.id} className="user-friend">
                  <Link
                    to={
                      friend.id === loggedInUser.id
                        ? "/user"
                        : `/userProfile/${friend.id}`
                    }
                    onClick={(e) => {
                      if (friend.id === loggedInUser.id) {
                        e.preventDefault();
                        window.location.href = "/user";
                      }
                    }}
                  >
                    <img
                      src={friend.profilePicture || defaultProfilePicture}
                      alt="Profile"
                      className="friend-profile-pic"
                    />
                    <span>
                      {friend.firstName} {friend.lastName}
                    </span>
                  </Link>
                </div>
              ))
            )}
          </div>
        );
      case "photos":
        return (
          <div className="photos">
            <h2>Photos</h2>
            <div className="photo-grid">
              {photos.filter(
                (photo) => photo.authorEmail === selectedUser.email
              ).length === 0 ? (
                <p>No Photos available.</p>
              ) : (
                photos
                  .filter((photo) => photo.authorEmail === selectedUser.email)
                  .map((photo, index) => (
                    <img
                      key={index}
                      src={photo.imageUrl}
                      alt={`${index}`}
                      className="photo-item"
                    />
                  ))
              )}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <>
      <div className="header">
        <i className="fab fa-facebook"></i>
        <form onSubmit={handleSearch}>
          <div className="search-container">
            <i className="fas fa-search search-icon"></i>
            <input
              type="search"
              className="search-bar"
              placeholder="Search Facebook"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </form>
        <div className="links">
          <Link className="nav-item" to="/home">
            <i className="i fa-solid fa-house"></i>
            <span className="tooltip-text">Home</span>
          </Link>
          <Link className="nav-item" to="/friends">
            <i className="i fa-solid fa-user-group"></i>
            <span className="tooltip-text">Friends</span>
          </Link>
          <Link className="nav-item" to="/videos">
            <i className="i fa-brands fa-youtube"></i>
            <span className="tooltip-text">Videos</span>
          </Link>
          <Link className="nav-item" to="/groups">
            <i className="i fa-solid fa-users"></i>
            <span className="grp-txt tooltip-text">Groups</span>
          </Link>
        </div>
        <div className="user-info">
          <Link to="/user" id="link">
            <img
              src={loggedInUser?.profilePicture || defaultProfilePicture}
              alt="Profile"
              className="profile-pic"
            />
          </Link>
          <span className="user-name">
            {loggedInUser?.firstName} {loggedInUser?.lastName}
          </span>
        </div>
      </div>
      <div className="user-page">
        <div className="profile-info">
          <img
            src={selectedUser?.coverPhoto || defaultCoverPhoto}
            alt={`${selectedUser?.firstName} ${selectedUser?.lastName}`}
            className="cover-photo"
          />
          <img
            src={selectedUser?.profilePicture || defaultProfilePicture}
            alt={`${selectedUser?.firstName} ${selectedUser?.lastName}`}
            className="profile-picture userPhoto"
          />
          <h1 className="userName">{`${selectedUser?.firstName} ${selectedUser?.lastName}`}</h1>
        </div>
        {renderButtons(selectedUser)}

        <hr />
        <div className="tabs">
          <button onClick={() => setActiveTab("posts")}>Posts</button>
          <button onClick={() => setActiveTab("about")}>About</button>
          <button onClick={() => setActiveTab("friends")}>Friends</button>
          <button onClick={() => setActiveTab("photos")}>Photos</button>
        </div>
        <div className="tab-content">{renderTabContent()}</div>
      </div>
    </>
  );
}
