import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

import "./Videos.css";

const defaultProfilePicture = "https://via.placeholder.com/150";

export default function Videos() {
  const [posts, setPosts] = useState([]);
  const [user, setUser] = useState({});
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();
  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user")) || {};
    const storedPosts = JSON.parse(localStorage.getItem("posts")) || [];
    setUser(storedUser);
    setPosts(storedPosts);
  }, []);

  const handleLikeToggle = (postId) => {
    const updatedPosts = posts.map((post) => {
      if (post.id === postId) {
        const likesArray = Array.isArray(post.likes) ? post.likes : [];
        const alreadyLiked = likesArray.includes(user.email);

        return {
          ...post,
          likes: alreadyLiked
            ? likesArray.filter((email) => email !== user.email)
            : [...likesArray, user.email],
        };
      }
      return post;
    });

    setPosts(updatedPosts);
    localStorage.setItem("posts", JSON.stringify(updatedPosts));
  };

  const handleDeletePost = (id) => {
    const updatedPosts = posts.map((post) =>
      post.id === id
        ? {
            ...post,
            deletedByUser: (post.deletedByUser || []).concat(user.email),
          }
        : post
    );
    setPosts(updatedPosts);
    localStorage.setItem("posts", JSON.stringify(updatedPosts));
  };
  const handleSearch = (e) => {
    e.preventDefault();
    navigate(`/search?term=${encodeURIComponent(searchTerm)}`);
  };
  return (
    <>
      <div className="header">
        <i className="fab fa-facebook"></i>
        <form onSubmit={handleSearch}>
          <div className="search-container">
            <i className="fas fa-search search-icon"></i>
            <input
              type="search"
              className="search-bar"
              placeholder="Search Facebook"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </form>
        <div className="links">
          <Link className="nav-item" to="/home">
            <i className="i fa-solid fa-house"></i>
            <span className="tooltip-text">Home</span>
          </Link>
          <Link className="nav-item" to="/friends">
            <i className="i fa-solid fa-user-group"></i>
            <span className="tooltip-text">Friends</span>
          </Link>
          <Link className="nav-item" to="/videos">
            <i className="i fa-brands fa-youtube"></i>
            <span className="tooltip-text">Videos</span>
          </Link>
          <Link className="nav-item" to="/groups">
            <i className="i fa-solid fa-users"></i>
            <span className="grp-txt tooltip-text">Groups</span>
          </Link>
        </div>
        <div className="user-info">
          <Link to="/user" id="link">
            <img
              src={user.profilePicture || defaultProfilePicture}
              alt="Profile"
              className="profile-pic"
            />
          </Link>
          <span className="user-name">
            {user.firstName} {user.lastName}
          </span>
        </div>
      </div>
      <div className="posts videos">
        {posts
          .filter(
            (post) =>
              post.media &&
              post.media.startsWith("data:video") &&
              !(post.deletedByUser || []).includes(user.email)
          )
          .map((post) => (
            <div key={post.id} className="post">
              <div className="post-header">
                <img
                  src={post.profilePicture || defaultProfilePicture}
                  alt="Author"
                  className="profile-picture"
                />
                <span className="span">{post.author}</span>
                <button
                  className="delete-button"
                  onClick={() => handleDeletePost(post.id)}
                >
                  <i className="fa-solid fa-xmark"></i>
                </button>
              </div>

              <p className="content">{post.content}</p>

              {post.media && post.media.startsWith("data:video") && (
                <div className="post-media-container">
                  <video
                    controls
                    src={post.media}
                    alt="Post media"
                    className="post-media"
                  ></video>
                </div>
              )}
              <div className="post-actions">
                <hr />
                <button
                  onClick={() => handleLikeToggle(post.id)}
                  className={
                    Array.isArray(post.likes) && post.likes.includes(user.email)
                      ? "liked"
                      : ""
                  }
                >
                  <i className="fa-solid fa-thumbs-up"></i>
                  {Array.isArray(post.likes) && post.likes.includes(user.email)
                    ? "Unlike"
                    : "Like"}
                  {Array.isArray(post.likes) ? post.likes.length : 0}
                </button>
              </div>
            </div>
          ))}
      </div>
    </>
  );
}
