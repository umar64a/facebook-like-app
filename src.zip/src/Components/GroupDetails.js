import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";
import { useNavigate } from "react-router-dom";

import "./GroupDetails.css";

const defaultProfilePicture = "https://via.placeholder.com/150";
const defaultGroupCoverPhoto = "https://via.placeholder.com/600x200";

export default function GroupDetails() {
  const [user, setUser] = useState({});
  const [group, setGroup] = useState({});
  const [activeTab, setActiveTab] = useState("discussion");
  const [activeMediaTab, setActiveMediaTab] = useState("photos");
  const [postContent, setPostContent] = useState("");
  const [postMedia, setPostMedia] = useState(null);
  const [discussionPosts, setDiscussionPosts] = useState([]);
  const [members, setMembers] = useState([]);
  const [userDetails, setUserDetails] = useState({});
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [hasJoined, setHasJoined] = useState(false);
  const [friendRequests, setFriendRequests] = useState([]);
  const [friends, setFriends] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();
  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user")) || {};
    setUser(storedUser);
    setLoggedInUser(storedUser);
    const location = window.location.href;
    const queryParams = new URLSearchParams(location.split("?")[1]);
    const groupId = queryParams.get("id");
    const storedFriends = JSON.parse(localStorage.getItem("friends")) || {};
    const storedRequests =
      JSON.parse(localStorage.getItem("friendRequests")) || [];
    setFriends(storedFriends[storedUser.id] || []);
    setFriendRequests(storedRequests);
    const groups = JSON.parse(localStorage.getItem("allGroups")) || [];
    const selectedGroup =
      groups.find((group) => group.id === parseInt(groupId, 10)) || {};

    setGroup(selectedGroup);
    const allStoredUsers = JSON.parse(localStorage.getItem("users")) || [];

    const storedPosts =
      JSON.parse(localStorage.getItem(`discussionPosts_${groupId}`)) || [];
    setDiscussionPosts(storedPosts);
    const memberDetails = {};
    (selectedGroup.members || []).forEach((memberId) => {
      const userDetail = allStoredUsers.find((user) => user.id === memberId);
      if (userDetail) {
        memberDetails[memberId] = userDetail;
      }
    });

    setUserDetails(memberDetails);
    setMembers(selectedGroup.members || []);

    if (
      selectedGroup.members &&
      selectedGroup.members.includes(storedUser.id)
    ) {
      setHasJoined(true);
    }
  }, []);

  const handlePostSubmit = (e) => {
    e.preventDefault();
    if (!postContent && !postMedia) return;
    const newPost = {
      id: Date.now(),
      groupId: group.id,
      authorEmail: user.email,
      author: `${user.firstName} ${user.lastName}`,
      profilePicture: user.profilePicture || defaultProfilePicture,
      content: postContent,
      media: postMedia,
      likes: [],
    };

    const updatedPosts = [newPost, ...discussionPosts];
    setDiscussionPosts(updatedPosts);
    localStorage.setItem(
      `discussionPosts_${group.id}`,
      JSON.stringify(updatedPosts)
    );
    setPostContent("");
    setPostMedia(null);
    const input = document.getElementById("post-media-input");
    if (input) {
      input.value = "";
    }
  };

  const handleMediaUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      setPostMedia(reader.result);
    };
    if (file) {
      reader.readAsDataURL(file);
    }
  };

  const handleLikeToggle = (postId) => {
    const updatedPosts = discussionPosts.map((post) => {
      if (post.id === postId) {
        const likesArray = Array.isArray(post.likes) ? post.likes : [];
        const alreadyLiked = likesArray.includes(user.email);

        return {
          ...post,
          likes: alreadyLiked
            ? likesArray.filter((email) => email !== user.email)
            : [...likesArray, user.email],
        };
      }
      return post;
    });

    setDiscussionPosts(updatedPosts);
    localStorage.setItem(
      `discussionPosts_${group.id}`,
      JSON.stringify(updatedPosts)
    );
  };

  const handleDeletePost = (id) => {
    const updatedPosts = discussionPosts.filter((post) => post.id !== id);
    setDiscussionPosts(updatedPosts);
    localStorage.setItem(
      `discussionPosts_${group.id}`,
      JSON.stringify(updatedPosts)
    );
  };

  const handleJoinGroup = () => {
    if (group.members && group.members.includes(loggedInUser.id)) return;

    const updatedGroup = {
      ...group,
      members: [...(group.members || []), loggedInUser.id],
    };

    const allGroups = JSON.parse(localStorage.getItem("allGroups")) || [];
    const updatedGroups = allGroups.map((grp) =>
      grp.id === group.id ? updatedGroup : grp
    );

    localStorage.setItem("allGroups", JSON.stringify(updatedGroups));
    setGroup(updatedGroup);
    setHasJoined(true);
  };

  const sendFriendRequest = (id) => {
    const selectedUser = userDetails[id];
    if (!selectedUser) return;

    const newRequest = {
      id: uuidv4(),
      senderId: user.id,
      senderName: `${user.firstName} ${user.lastName}`,
      senderProfilePicture: user.profilePicture || defaultProfilePicture,
      receiverId: selectedUser.id,
    };

    const updatedRequests = [...friendRequests, newRequest];
    setFriendRequests(updatedRequests);
    localStorage.setItem("friendRequests", JSON.stringify(updatedRequests));
  };

  const cancelFriendRequest = (id) => {
    const updatedRequests = friendRequests.filter(
      (request) => !(request.receiverId === id && request.senderId === user.id)
    );
    setFriendRequests(updatedRequests);
    localStorage.setItem("friendRequests", JSON.stringify(updatedRequests));
  };

  const handleSearch = (e) => {
    e.preventDefault();
    navigate(`/search?term=${encodeURIComponent(searchTerm)}`);
  };
  const renderMediaTabContent = () => {
    const photoPosts = discussionPosts.filter(
      (post) => post.media && post.media.startsWith("data:image")
    );
    const videoPosts = discussionPosts.filter(
      (post) => post.media && post.media.startsWith("data:video")
    );

    const allPhotos = [
      group.coverPhoto,
      ...photoPosts.map((post) => post.media),
    ];

    switch (activeMediaTab) {
      case "photos":
        return (
          <div className="photo-grid">
            {allPhotos.length > 0 ? (
              allPhotos.map((photo, index) =>
                photo ? (
                  <img
                    key={index}
                    src={photo}
                    alt={`${index}`}
                    className="photo-item"
                  />
                ) : null
              )
            ) : (
              <p>No photos available.</p>
            )}
          </div>
        );
      case "videos":
        return (
          <div className="photo-grid">
            {videoPosts.length > 0 ? (
              videoPosts.map((post) => (
                <video
                  key={post.id}
                  controls
                  src={post.media}
                  alt="Post media"
                  className="photo-item"
                ></video>
              ))
            ) : (
              <p>No videos available.</p>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "discussion":
        return (
          <div className="posts">
            <div className="create-post">
              <form onSubmit={handlePostSubmit}>
                <textarea
                  placeholder="What's on your mind?"
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                ></textarea>
                <hr />
                <label htmlFor="post-media-input" className="post-upload">
                  <i className="fa-solid fa-images"></i>Photo/Video
                </label>
                <input
                  type="file"
                  accept="image/*, video/*"
                  onChange={handleMediaUpload}
                  id="post-media-input"
                  style={{ display: "none" }}
                />
                <button
                  id="post-btn"
                  type="submit"
                  style={{
                    display: postContent || postMedia ? "block" : "none",
                  }}
                >
                  Post
                </button>
              </form>
            </div>
            {discussionPosts.map((post) => (
              <div key={post.id} className="post">
                <div className="post-header">
                  <img
                    src={post.profilePicture || defaultProfilePicture}
                    alt="Author"
                    className="profile-picture"
                  />
                  <span className="span">{post.author}</span>
                  {post.authorEmail === user.email && (
                    <button
                      className="delete-button"
                      onClick={() => handleDeletePost(post.id)}
                    >
                      <i className="fa-solid fa-xmark"></i>
                    </button>
                  )}
                </div>
                <p className="content">{post.content}</p>
                {post.image && (
                  <div className="post-media-container">
                    <img src={post.image} alt="Post" className="post-media" />
                  </div>
                )}
                {post.media && (
                  <div className="post-media-container">
                    {post.media.startsWith("data:image") ? (
                      <img
                        src={post.media}
                        alt="Post media"
                        className="post-media"
                      />
                    ) : (
                      <video
                        controls
                        src={post.media}
                        alt="Post media"
                        className="post-media"
                      ></video>
                    )}
                  </div>
                )}
                <div className="post-actions">
                  <hr />
                  <button
                    onClick={() => handleLikeToggle(post.id)}
                    className={
                      Array.isArray(post.likes) &&
                      post.likes.includes(user.email)
                        ? "liked"
                        : ""
                    }
                  >
                    <i className="fa-solid fa-thumbs-up"></i>
                    {Array.isArray(post.likes) &&
                    post.likes.includes(user.email)
                      ? "Unlike"
                      : "Like"}{" "}
                    {Array.isArray(post.likes) ? post.likes.length : 0}
                  </button>
                </div>
              </div>
            ))}
          </div>
        );

      case "members":
        return (
          <div className="members-list">
            <h2>Members</h2>
            {members.length ? (
              members.map((memberId) => {
                const member = userDetails[memberId];
                if (!member) return null;

                const isCurrentUser = member.id === loggedInUser.id;
                const isFriend = friends.some(
                  (friend) => friend.id === memberId
                );
                const hasSentRequest = friendRequests.some(
                  (req) =>
                    req.senderId === loggedInUser.id &&
                    req.receiverId === memberId
                );

                return (
                  <div key={memberId} className="member">
                    <Link
                      to={isCurrentUser ? "/user" : `/userProfile/${member.id}`}
                    >
                      <img
                        src={member.profilePicture || defaultProfilePicture}
                        alt={`${member.firstName}'s profile`}
                        className="friend-profile-pic"
                      />
                      <span>
                        {member.firstName} {member.lastName}
                      </span>
                    </Link>
                    {!isCurrentUser &&
                      (hasSentRequest ? (
                        <button
                          className="cancel-btn"
                          onClick={() => cancelFriendRequest(memberId)}
                        >
                          <i className="fas fa-user-xmark"></i>
                          Cancel request
                        </button>
                      ) : !isFriend ? (
                        <button
                          className="add-btn"
                          onClick={() => sendFriendRequest(memberId)}
                        >
                          <i class="fas fa-user-plus"></i>
                          Add friend
                        </button>
                      ) : null)}
                  </div>
                );
              })
            ) : (
              <p>No members yet.</p>
            )}
          </div>
        );

      case "about":
        return (
          <div className="group-about">
            <h2>About</h2>

            <div className="field">
              <p>
                <strong>Description:</strong>
                <br />
                <span>
                  {group.description ? group.description : "Not Available"}
                </span>
              </p>
            </div>

            <div className="field">
              <p>
                <strong>Location:</strong>
                <br />
                <span>{group.location ? group.location : "Not Available"}</span>
              </p>
            </div>

            <div className="field">
              <p>
                <strong>History:</strong>
                <br />
                <span>{group.history ? group.history : "Not Available"}</span>
              </p>
            </div>
          </div>
        );
      case "media":
        return (
          <div className="media">
            <h2>Media</h2>
            <div className="media-tabs">
              <button onClick={() => setActiveMediaTab("photos")}>
                Photos
              </button>
              <button onClick={() => setActiveMediaTab("videos")}>
                Videos
              </button>
            </div>
            {renderMediaTabContent()}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <>
      <div className="header">
        <i className="fab fa-facebook"></i>
        <form onSubmit={handleSearch}>
          <div className="search-container">
            <i className="fas fa-search search-icon"></i>
            <input
              type="search"
              className="search-bar"
              placeholder="Search Facebook"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </form>
        <div className="links">
          <Link className="nav-item" to="/home">
            <i className="i fa-solid fa-house"></i>
            <span className="tooltip-text">Home</span>
          </Link>
          <Link className="nav-item" to="/friends">
            <i className="i fa-solid fa-user-group"></i>
            <span className="tooltip-text">Friends</span>
          </Link>
          <Link className="nav-item" to="/videos">
            <i className="i fa-brands fa-youtube"></i>
            <span className="tooltip-text">Videos</span>
          </Link>
          <Link className="nav-item" to="/groups">
            <i className="i fa-solid fa-users"></i>
            <span className="grp-txt tooltip-text">Groups</span>
          </Link>
        </div>
        <div className="user-info">
          <Link to="/user" id="link">
            <img
              src={user.profilePicture || defaultProfilePicture}
              alt="Profile"
              className="profile-pic"
            />
          </Link>
          <span className="user-name">
            {user.firstName} {user.lastName}
          </span>
        </div>
      </div>

      <div className="groupsection">
        <div className="group-details">
          <img
            src={group.coverPhoto || defaultGroupCoverPhoto}
            alt="Group Cover"
            className="cover-photo"
          />
          <h2 className="group-name">{group.name}</h2>
          {hasJoined ? (
            <button className="joined-btn" disabled>
              <i class="fas fa-users"></i>
              <i class="fas fa-check"></i>
              Joined
            </button>
          ) : (
            <button className="join-btn" onClick={handleJoinGroup}>
              <i class="fas fa-users"></i>
              <i class="plus fas fa-plus"></i>
              Join group
            </button>
          )}
        </div>

        <hr />
        <div className="tabs">
          <button onClick={() => setActiveTab("discussion")}>Discussion</button>
          <button onClick={() => setActiveTab("members")}>Members</button>
          <button onClick={() => setActiveTab("about")}>About</button>
          <button onClick={() => setActiveTab("media")}>Media</button>
        </div>
        {renderTabContent()}
      </div>
    </>
  );
}
