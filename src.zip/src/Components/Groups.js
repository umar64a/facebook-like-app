import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Groups.css";

const defaultProfilePicture = "https://via.placeholder.com/150";
const defaultGroupCoverPhoto = "https://via.placeholder.com/600x200";

export default function Groups() {
  const [user, setUser] = useState({});
  const [activeTab, setActiveTab] = useState("Discover");
  const [allGroups, setAllGroups] = useState([]);
  const [joinedGroups, setJoinedGroups] = useState([]);
  const [groupName, setGroupName] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user")) || {};
    setUser(storedUser);
    fetchAllGroups();
    fetchJoinedGroups();
  }, []);

  const fetchAllGroups = () => {
    const groups = JSON.parse(localStorage.getItem("allGroups")) || [];
    setAllGroups(groups);
  };
  const fetchJoinedGroups = () => {
    const user = JSON.parse(localStorage.getItem("user")) || {};
    const allGroups = JSON.parse(localStorage.getItem("allGroups")) || [];
    const userJoinedGroups = allGroups.filter(
      (group) => group.members && group.members.includes(user.id)
    );
    setJoinedGroups([...userJoinedGroups]);
  };
  const handleInputChange = (e) => {
    setGroupName(e.target.value);
  };

  const createNewGroup = (groupName) => {
    const newGroup = {
      id: Date.now(),
      name: groupName,
      coverPhoto: defaultGroupCoverPhoto,
      createdBy: user.email,
      members: [user.id],
    };

    const updatedGroups = [...allGroups, newGroup];
    setAllGroups(updatedGroups);
    setJoinedGroups((prev) => [...prev, newGroup]);

    localStorage.setItem("allGroups", JSON.stringify(updatedGroups));
    localStorage.setItem("group", JSON.stringify(newGroup));
    localStorage.setItem("discussionPosts", JSON.stringify([]));

    navigate(`/UserGroup?id=${newGroup.id}`);
  };

  const navigateToGroup = (group) => {
    if (group.createdBy === user.email) {
      navigate(`/UserGroup?id=${group.id}`);
    } else {
      navigate(`/GroupDetails?id=${group.id}`);
    }
  };
  const handleJoinGroup = (groupId) => {
    const user = JSON.parse(localStorage.getItem("user")) || {};
    const groups = JSON.parse(localStorage.getItem("allGroups")) || [];
    const updatedGroups = groups.map((group) => {
      if (group.id === groupId) {
        return {
          ...group,
          members: [...(group.members || []), user.id],
        };
      }
      return group;
    });

    localStorage.setItem("allGroups", JSON.stringify(updatedGroups));
    setAllGroups(updatedGroups);
    fetchJoinedGroups();
  };
  const handleSearch = (e) => {
    e.preventDefault();
    navigate(`/search?term=${encodeURIComponent(searchTerm)}`);
  };
  const renderContent = () => {
    switch (activeTab) {
      case "Discover":
        const discoverGroups = allGroups.filter(
          (group) =>
            !joinedGroups.find((joinedGroup) => joinedGroup.id === group.id)
        );
        return (
          <div className="recomend">
            <h2>More suggestions</h2>
            {discoverGroups.length ? (
              discoverGroups.map((group) => (
                <div key={group.id} className="group-card">
                  <Link to={`/GroupDetails?id=${group.id}`}>
                    <img
                      src={group.coverPhoto || defaultGroupCoverPhoto}
                      alt={group.name}
                      className="group-cover-photo"
                    />
                    <span className="group-Name">{group.name}</span>
                  </Link>
                  <button
                    onClick={() => handleJoinGroup(group.id)}
                    className="group-btns"
                    disabled={joinedGroups.some((g) => g.id === group.id)}
                  >
                    Join group
                  </button>
                </div>
              ))
            ) : (
              <p>No groups available.</p>
            )}
          </div>
        );
      case "YourGroups":
        return (
          <div className="recomend">
            <h2>All groups you've joined</h2>
            {joinedGroups.length ? (
              joinedGroups.map((group) => (
                <div key={group.id} className="group-card">
                  <img
                    src={group.coverPhoto || defaultGroupCoverPhoto}
                    alt={group.name}
                    className="group-cover-photo"
                  />
                  <span className="group-Name">{group.name}</span>
                  <br />

                  <button
                    className="group-btns"
                    onClick={() => navigateToGroup(group)}
                  >
                    View group
                  </button>
                </div>
              ))
            ) : (
              <p>No groups available.</p>
            )}
          </div>
        );
      case "CreateNewGroup":
        return (
          <div className="creat-group">
            <h2>Create group</h2>
            <input
              id="groupName"
              type="text"
              placeholder="Group Name"
              className="groupName"
              value={groupName}
              onChange={handleInputChange}
            />
            <br />
            {groupName && (
              <button
                className="create"
                onClick={() => createNewGroup(groupName)}
              >
                Create
              </button>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <>
      <div className="header">
        <i className="fab fa-facebook"></i>
        <form onSubmit={handleSearch}>
          <div className="search-container">
            <i className="fas fa-search search-icon"></i>
            <input
              type="search"
              className="search-bar"
              placeholder="Search Facebook"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </form>
        <div className="links">
          <Link className="nav-item" to="/home">
            <i className="i fa-solid fa-house"></i>
            <span className="tooltip-text">Home</span>
          </Link>
          <Link className="nav-item" to="/friends">
            <i className="i fa-solid fa-user-group"></i>
            <span className="tooltip-text">Friends</span>
          </Link>
          <Link className="nav-item" to="/videos">
            <i className="i fa-brands fa-youtube"></i>
            <span className="tooltip-text">Videos</span>
          </Link>
          <Link className="nav-item" to="/groups">
            <i className="i fa-solid fa-users"></i>
            <span className="grp-txt tooltip-text">Groups</span>
          </Link>
        </div>
        <div className="user-info">
          <Link to="/user" id="link">
            <img
              src={user.profilePicture || defaultProfilePicture}
              alt="Profile"
              className="profile-pic"
            />
          </Link>
          <span className="user-name">
            {user.firstName} {user.lastName}
          </span>
        </div>
      </div>
      <div className="groupsPage">
        <div className="tab-btns">
          <button
            className={`tab ${activeTab === "Discover" ? "active" : ""}`}
            onClick={() => setActiveTab("Discover")}
          >
            Discover
          </button>
          <button
            className={`tab ${activeTab === "YourGroups" ? "active" : ""}`}
            onClick={() => setActiveTab("YourGroups")}
          >
            Your groups
          </button>
          <button
            className={`CreateNewGroup ${
              activeTab === "CreateNewGroup" ? "active" : ""
            }`}
            onClick={() => setActiveTab("CreateNewGroup")}
          >
            <i className="fa-solid fa-plus"></i>
            Create new group
          </button>
        </div>
        {renderContent()}
      </div>
    </>
  );
}
