import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

import "./User.css";

const defaultProfilePicture = "https://via.placeholder.com/150";
const defaultCoverPhoto = "https://via.placeholder.com/800x200";

export default function User() {
  const [user, setUser] = useState({});
  const [profilePicture, setProfilePicture] = useState("");
  const [coverPhoto, setCoverPhoto] = useState("");
  const [posts, setPosts] = useState([]);
  const [photos, setPhotos] = useState([]);
  const [activeTab, setActiveTab] = useState("posts");
  const [isEditing, setIsEditing] = useState(null);
  const [editValue, setEditValue] = useState("");
  const [showSaveButton, setShowSaveButton] = useState(false);
  const [friends, setFriends] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();
  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    const storedPosts = JSON.parse(localStorage.getItem("posts")) || [];
    const storedPhotos = JSON.parse(localStorage.getItem("photos")) || [];
    const storedFriends = JSON.parse(localStorage.getItem("friends")) || {};
    if (storedUser) {
      setUser(storedUser);
      setProfilePicture(storedUser.profilePicture || defaultProfilePicture);
      setCoverPhoto(storedUser.coverPhoto || defaultCoverPhoto);
      setPhotos(
        storedPhotos.filter((photo) => photo.authorEmail === storedUser.email)
      );
    } else {
      setProfilePicture(defaultProfilePicture);
      setCoverPhoto(defaultCoverPhoto);
    }
    if (storedUser) {
      setUser(storedUser);
      setFriends(storedFriends[storedUser.id] || []);
    }
    if (storedPosts) {
      setPosts(storedPosts);
    }
  }, []);
  const handleProfilePictureUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePicture(reader.result);
        setShowSaveButton(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCoverPhotoUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCoverPhoto(reader.result);
        setShowSaveButton(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    const updatedUser = {
      ...user,
      profilePicture:
        profilePicture || user.profilePicture || defaultProfilePicture,
      coverPhoto: coverPhoto || user.coverPhoto || defaultCoverPhoto,
    };

    const existingUsers = JSON.parse(localStorage.getItem("users")) || [];
    const updatedUsers = existingUsers.map((u) =>
      u.email === updatedUser.email ? updatedUser : u
    );

    localStorage.setItem("users", JSON.stringify(updatedUsers));
    localStorage.setItem("user", JSON.stringify(updatedUser));

    const newPosts = [];
    const newPhotos = [...photos];
    if (profilePicture) {
      newPosts.push({
        id: Date.now(),
        authorEmail: user.email,
        author: `${user.firstName} ${user.lastName}`,
        profilePicture: updatedUser.profilePicture,
        content: "Updated profile picture",
        profileImage: profilePicture,
      });
      newPhotos.push({ authorEmail: user.email, imageUrl: profilePicture });
    } else if (coverPhoto) {
      newPosts.push({
        id: Date.now() + 1,
        authorEmail: user.email,
        author: `${user.firstName} ${user.lastName}`,
        profilePicture: updatedUser.profilePicture,
        content: "Updated cover photo",
        image: coverPhoto,
      });
      newPhotos.push({ authorEmail: user.email, imageUrl: coverPhoto });
    }
    const updatedPosts = posts.map((post) =>
      post.authorEmail === updatedUser.email
        ? { ...post, profilePicture: updatedUser.profilePicture }
        : post
    );

    setPosts([...newPosts, ...updatedPosts]);
    localStorage.setItem(
      "posts",
      JSON.stringify([...newPosts, ...updatedPosts])
    );

    const allPhotos = JSON.parse(localStorage.getItem("photos")) || [];
    const updatedPhotos = [
      ...allPhotos.filter((photo) => photo.authorEmail !== user.email),
      ...newPhotos,
    ];

    localStorage.setItem("photos", JSON.stringify(updatedPhotos));
    setPhotos(newPhotos);
    setUser(updatedUser);
    setProfilePicture("");
    setCoverPhoto("");
    setShowSaveButton(false);
  };

  const handleLikeToggle = (postId) => {
    const updatedPosts = posts.map((post) => {
      if (post.id === postId) {
        const likesArray = Array.isArray(post.likes) ? post.likes : [];
        const alreadyLiked = likesArray.includes(user.email);

        return {
          ...post,
          likes: alreadyLiked
            ? likesArray.filter((email) => email !== user.email)
            : [...likesArray, user.email],
        };
      }
      return post;
    });

    setPosts(updatedPosts);
    localStorage.setItem("posts", JSON.stringify(updatedPosts));
  };

  const handleDeletePost = (id) => {
    const updatedPosts = posts.map((post) =>
      post.id === id
        ? {
            ...post,
            deletedByUser: (post.deletedByUser || []).concat(user.email),
          }
        : post
    );
    setPosts(updatedPosts);
    localStorage.setItem("posts", JSON.stringify(updatedPosts));
  };

  const openModal = (field, value) => {
    setIsEditing(field);
    setEditValue(value || "");
  };

  const closeModal = () => {
    setIsEditing(null);
    setEditValue("");
  };

  const saveEdit = () => {
    const updatedUser = { ...user, [isEditing]: editValue };
    setUser(updatedUser);

    const existingUsers = JSON.parse(localStorage.getItem("users")) || [];
    const updatedUsers = existingUsers.map((u) =>
      u.email === updatedUser.email ? updatedUser : u
    );

    localStorage.setItem("users", JSON.stringify(updatedUsers));
    localStorage.setItem("user", JSON.stringify(updatedUser));

    closeModal();
  };

  const deleteField = (field) => {
    const updatedUser = { ...user, [field]: "" };
    setUser(updatedUser);

    const existingUsers = JSON.parse(localStorage.getItem("users")) || [];
    const updatedUsers = existingUsers.map((u) =>
      u.email === updatedUser.email ? updatedUser : u
    );

    localStorage.setItem("users", JSON.stringify(updatedUsers));
    localStorage.setItem("user", JSON.stringify(updatedUser));
  };

  const handleSearch = (e) => {
    e.preventDefault();
    navigate(`/search?term=${encodeURIComponent(searchTerm)}`);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "posts":
        return (
          <div className="posts">
            {posts
              .filter(
                (post) =>
                  post.authorEmail === user.email &&
                  !(post.deletedByUser || []).includes(user.email)
              )
              .map((post) => (
                <div key={post.id} className="post">
                  <div className="post-header">
                    <img
                      src={post.profilePicture || defaultProfilePicture}
                      alt="Author"
                      className="profile-picture"
                    />
                    <span className="span">{post.author}</span>
                    <button
                      className="delete-button"
                      onClick={() => handleDeletePost(post.id)}
                    >
                      <i className="fa-solid fa-xmark"></i>
                    </button>
                  </div>

                  <p className="content">{post.content}</p>
                  {post.profileImage && (
                    <div className="post-media-container">
                      <img
                        src={post.profileImage}
                        alt="Post"
                        className="post-media post-profile"
                      />
                    </div>
                  )}
                  {post.image && (
                    <div className="post-media-container">
                      <img src={post.image} alt="Post" className="post-media" />
                    </div>
                  )}
                  {post.media && (
                    <div className="post-media-container">
                      {post.media.startsWith("data:image") ? (
                        <img
                          src={post.media}
                          alt="Post media"
                          className="post-media"
                        />
                      ) : (
                        <video
                          controls
                          src={post.media}
                          alt="Post media"
                          className="post-media"
                        ></video>
                      )}
                    </div>
                  )}
                  <div className="post-actions">
                    <hr />
                    <button
                      onClick={() => handleLikeToggle(post.id)}
                      className={
                        Array.isArray(post.likes) &&
                        post.likes.includes(user.email)
                          ? "liked"
                          : ""
                      }
                    >
                      <i className="fa-solid fa-thumbs-up"></i>
                      {Array.isArray(post.likes) &&
                      post.likes.includes(user.email)
                        ? "Unlike"
                        : "Like"}
                      {Array.isArray(post.likes) ? post.likes.length : 0}
                    </button>
                  </div>
                </div>
              ))}
          </div>
        );
      case "about":
        return (
          <div className="about">
            <h2>About</h2>
            <p>
              <strong>Workplace:</strong> {user.workplace || ""}
              <div className="btns">
                {user.workplace && (
                  <button
                    className="delete-button"
                    onClick={() => deleteField("workplace")}
                  >
                    <i className="del fa-solid fa-trash"></i>
                  </button>
                )}
                <button onClick={() => openModal("workplace", user.workplace)}>
                  <i className="pen fa-solid fa-pen"></i>
                </button>
              </div>
            </p>
            <p>
              <strong>High School:</strong> {user.highSchool || ""}
              <div className="btns">
                {user.highSchool && (
                  <button
                    className="delete-button"
                    onClick={() => deleteField("highSchool")}
                  >
                    <i className="del fa-solid fa-trash"></i>
                  </button>
                )}
                <button
                  onClick={() => openModal("highSchool", user.highSchool)}
                >
                  <i className="pen fa-solid fa-pen"></i>
                </button>
              </div>
            </p>
            <p>
              <strong>College:</strong> {user.college || ""}
              <div className="btns">
                {user.college && (
                  <button
                    className="delete-button"
                    onClick={() => deleteField("college")}
                  >
                    <i className="del fa-solid fa-trash"></i>
                  </button>
                )}
                <button onClick={() => openModal("college", user.college)}>
                  <i className="pen fa-solid fa-pen"></i>
                </button>
              </div>
            </p>
            <p>
              <strong>City:</strong> {user.city || ""}
              <div className="btns">
                {user.city && (
                  <button
                    className="delete-button"
                    onClick={() => deleteField("city")}
                  >
                    <i className="del fa-solid fa-trash"></i>
                  </button>
                )}
                <button onClick={() => openModal("city", user.city)}>
                  <i className="pen fa-solid fa-pen"></i>
                </button>
              </div>
            </p>
            <p>
              <strong>Location:</strong> {user.hometown || ""}
              <div className="btns">
                {user.hometown && (
                  <button
                    className="delete-button"
                    onClick={() => deleteField("hometown")}
                  >
                    <i className="del fa-solid fa-trash"></i>
                  </button>
                )}
                <button onClick={() => openModal("hometown", user.hometown)}>
                  <i className="pen fa-solid fa-pen"></i>
                </button>
              </div>
            </p>
            <p>
              <strong>Relation:</strong> {user.relation || ""}
              <div className="btns">
                {user.relation && (
                  <button
                    className="delete-button"
                    onClick={() => deleteField("relation")}
                  >
                    <i className="del fa-solid fa-trash"></i>
                  </button>
                )}
                <button onClick={() => openModal("relation", user.relation)}>
                  <i className="pen fa-solid fa-pen"></i>
                </button>
              </div>
            </p>
            <p>
              <strong>Mobile:</strong> {user.phone || ""}
              <div className="btns">
                {user.phone && (
                  <button
                    className="delete-button"
                    onClick={() => deleteField("phone")}
                  >
                    <i className="del fa-solid fa-trash"></i>
                  </button>
                )}
                <button onClick={() => openModal("phone", user.phone)}>
                  <i className="pen fa-solid fa-pen"></i>
                </button>
              </div>
            </p>
          </div>
        );
      case "friends":
        return (
          <div className="userFriend-list">
            <h2>Friends</h2>
            {friends.length === 0 ? (
              <p>No friends added yet.</p>
            ) : (
              friends.map((friend) => (
                <div key={friend.id} className="user-friend">
                  <Link to={`/userProfile/${friend.id}`}>
                    <img
                      src={friend.profilePicture || defaultProfilePicture}
                      alt="Profile"
                      className="friend-profile-pic"
                    />
                    <span>
                      {friend.firstName} {friend.lastName}
                    </span>
                  </Link>
                </div>
              ))
            )}
          </div>
        );
      case "photos":
        return (
          <div className="photos">
            <h2>Photos</h2>
            <div className="photo-grid">
              {photos.filter((photo) => photo.authorEmail === user.email)
                .length === 0 ? (
                <p>No Photos available.</p>
              ) : (
                photos
                  .filter((photo) => photo.authorEmail === user.email)
                  .map((photo, index) => (
                    <img
                      key={index}
                      src={photo.imageUrl}
                      alt={`${index}`}
                      className="photo-item"
                    />
                  ))
              )}
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <>
      <div className="header">
        <i className="fab fa-facebook"></i>
        <form onSubmit={handleSearch}>
          <div className="search-container">
            <i className="fas fa-search search-icon"></i>
            <input
              type="search"
              className="search-bar"
              placeholder="Search Facebook"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </form>
        <div className="links">
          <Link className="nav-item" to="/home">
            <i className="i fa-solid fa-house"></i>
            <span className="tooltip-text">Home</span>
          </Link>
          <Link className="nav-item" to="/friends">
            <i className="i fa-solid fa-user-group"></i>
            <span className="tooltip-text">Friends</span>
          </Link>
          <Link className="nav-item" to="/videos">
            <i className="i fa-brands fa-youtube"></i>
            <span className="tooltip-text">Videos</span>
          </Link>
          <Link className="nav-item" to="/groups">
            <i className="i fa-solid fa-users"></i>
            <span className="grp-txt tooltip-text">Groups</span>
          </Link>
        </div>

        <div className="user-info">
          <Link to="/user" id="link">
            <img
              src={user.profilePicture || defaultProfilePicture}
              alt="Profile"
              className="profile-pic"
            />
          </Link>
          <span className="user-name">
            {user.firstName} {user.lastName}
          </span>
        </div>
      </div>
      <div className="user-page">
        <div className="profile-info">
          <img
            src={coverPhoto || user.coverPhoto || defaultCoverPhoto}
            alt="Cover"
            className="cover-photo"
          />
          <label htmlFor="cover-input" className="cover-camera">
            <i className="fas fa-camera"></i>Edit cover photo
          </label>
          <input
            type="file"
            accept="image/*"
            onChange={handleCoverPhotoUpload}
            id="cover-input"
            style={{ display: "none" }}
          />
          <img
            src={profilePicture || user.profilePicture || defaultProfilePicture}
            alt="Profile"
            className="profile-picture photo"
          />
          <h1 className="name">
            {user.firstName} {user.lastName}
          </h1>
          <label htmlFor="profile-input" className=" profile-camera">
            <i className="fas fa-camera"></i>
          </label>
          <input
            type="file"
            accept="image/*"
            onChange={handleProfilePictureUpload}
            id="profile-input"
            style={{ display: "none" }}
          />
          {showSaveButton && (
            <button className="save-btn" onClick={handleSave}>
              Save
            </button>
          )}
        </div>
        <hr />
        <div className="tabs">
          <button onClick={() => setActiveTab("posts")}>Posts</button>
          <button onClick={() => setActiveTab("about")}>About</button>
          <button onClick={() => setActiveTab("friends")}>Friends</button>
          <button onClick={() => setActiveTab("photos")}>Photos</button>
        </div>
        {renderTabContent()}
      </div>
      {isEditing && (
        <div className="modal">
          <div className="modal-content">
            <h2>
              Edit {isEditing.charAt(0).toUpperCase() + isEditing.slice(1)}
            </h2>
            <input
              type="text"
              value={editValue}
              onChange={(e) => setEditValue(e.target.value)}
            />
            <button onClick={saveEdit}>Save</button>
            <button onClick={closeModal}>Cancel</button>
          </div>
        </div>
      )}
    </>
  );
}
