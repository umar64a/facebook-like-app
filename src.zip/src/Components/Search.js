import React, { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";

import "./Search.css";

const defaultProfilePicture = "https://via.placeholder.com/150";
const defaultGroupCoverPhoto = "https://via.placeholder.com/600x200";

export default function Search() {
  const [searchResults, setSearchResults] = useState({ users: [], groups: [] });
  const [user, setUser] = useState({});
  const [activeTab, setActiveTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [joinedGroups, setJoinedGroups] = useState([]);
  const [friends, setFriends] = useState([]);
  const [friendRequests, setFriendRequests] = useState([]);
  const location = useLocation();
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(location.search);
  const queryTerm = queryParams.get("term") || "";

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user")) || {};
    const storedFriends = JSON.parse(localStorage.getItem("friends")) || {};
    const storedRequests =
      JSON.parse(localStorage.getItem("friendRequests")) || [];
    const allUsers = JSON.parse(localStorage.getItem("users")) || [];
    const allGroups = JSON.parse(localStorage.getItem("allGroups")) || [];

    if (!storedUser.id) {
      storedUser.id = uuidv4();
      localStorage.setItem("user", JSON.stringify(storedUser));
    }

    const userFriends = storedFriends[storedUser.id] || [];
    const userJoinedGroups = allGroups.filter(
      (group) => group.members && group.members.includes(storedUser.id)
    );

    setUser(storedUser);
    setFriends(userFriends);
    setJoinedGroups(userJoinedGroups);
    setFriendRequests(storedRequests);

    const filteredUsers = allUsers.filter((user) => user.id !== storedUser.id);
    const filteredGroups = allGroups.filter((group) =>
      group.name.toLowerCase().includes(queryTerm.toLowerCase())
    );

    setSearchResults({
      users: filteredUsers.filter((user) =>
        `${user.firstName} ${user.lastName}`
          .toLowerCase()
          .includes(queryTerm.toLowerCase())
      ),
      groups: filteredGroups,
    });
    setSearchTerm(queryTerm);
  }, [queryTerm]);

  const isFriend = (userId) => {
    return friends.some((friend) => friend.id === userId);
  };

  const hasSentFriendRequest = (userId) => {
    return friendRequests.some(
      (request) => request.receiverId === userId && request.senderId === user.id
    );
  };

  const sendFriendRequest = (id) => {
    const selectedUser = searchResults.users.find((user) => user.id === id);
    const newRequest = {
      id: uuidv4(),
      senderId: user.id,
      senderName: `${user.firstName} ${user.lastName}`,
      senderProfilePicture: user.profilePicture || defaultProfilePicture,
      receiverId: selectedUser.id,
    };

    const updatedRequests = [...friendRequests, newRequest];
    setFriendRequests(updatedRequests);
    localStorage.setItem("friendRequests", JSON.stringify(updatedRequests));
  };

  const cancelFriendRequest = (id) => {
    const updatedRequests = friendRequests.filter(
      (request) => !(request.receiverId === id && request.senderId === user.id)
    );
    setFriendRequests(updatedRequests);
    localStorage.setItem("friendRequests", JSON.stringify(updatedRequests));
  };

  const isGroupJoined = (groupId) => {
    return joinedGroups.some((group) => group.id === groupId);
  };

  const handleJoinGroup = (groupId) => {
    const user = JSON.parse(localStorage.getItem("user")) || {};
    const groups = JSON.parse(localStorage.getItem("allGroups")) || [];
    const updatedGroups = groups.map((group) => {
      if (group.id === groupId) {
        return {
          ...group,
          members: [...(group.members || []), user.id],
        };
      }
      return group;
    });

    localStorage.setItem("allGroups", JSON.stringify(updatedGroups));
    setJoinedGroups(
      updatedGroups.filter((group) => group.members.includes(user.id))
    );
  };

  const navigateToGroup = (group) => {
    if (group.createdBy === user.email) {
      navigate(`/UserGroup?id=${group.id}`);
    } else {
      navigate(`/GroupDetails?id=${group.id}`);
    }
  };
  const handleSearch = (e) => {
    e.preventDefault();
    navigate(`/search?term=${encodeURIComponent(searchTerm)}`);
  };
  const filteredUnjoinedGroups = searchResults.groups.filter(
    (g) => !isGroupJoined(g.id)
  );
  const hasJoinedGroups = joinedGroups.length > 0;
  const hasFilteredGroups = filteredUnjoinedGroups.length > 0;

  const hasGroups = hasJoinedGroups || hasFilteredGroups;

  const renderContent = () => {
    switch (activeTab) {
      case "all":
        return (
          <div className="recommendations">
            <h2>All Peoples & Groups</h2>
            {searchResults.users.length > 0 ? (
              searchResults.users.map((u) => (
                <div key={u.id} className="recommendation user">
                  <Link to={`/userProfile/${u.id}`}>
                    <img
                      src={u.profilePicture || defaultProfilePicture}
                      alt={`${u.firstName} ${u.lastName}`}
                      className="recommendation-pic"
                    />
                    <span>{`${u.firstName} ${u.lastName}`}</span>
                  </Link>
                  {u.id !== user.id && (
                    <>
                      {!isFriend(u.id) && !hasSentFriendRequest(u.id) && (
                        <button onClick={() => sendFriendRequest(u.id)}>
                          Add friend
                        </button>
                      )}
                      {hasSentFriendRequest(u.id) && (
                        <button onClick={() => cancelFriendRequest(u.id)}>
                          Cancel request
                        </button>
                      )}
                    </>
                  )}
                </div>
              ))
            ) : (
              <p>No users found</p>
            )}
            {hasGroups ? (
              <>
                {hasJoinedGroups && (
                  <>
                    {joinedGroups.map((g) => (
                      <div key={g.id} className="group-card">
                        <img
                          src={g.coverPhoto || defaultGroupCoverPhoto}
                          alt={g.name}
                          className="group-cover-photo"
                        />
                        <span className="group-Name">{g.name}</span>
                        <button
                          className="view-btn"
                          onClick={() => navigateToGroup(g)}
                        >
                          View group
                        </button>
                      </div>
                    ))}
                  </>
                )}
                {hasFilteredGroups && (
                  <>
                    {filteredUnjoinedGroups.map((g) => (
                      <div key={g.id} className="group-card">
                        <Link to={`/GroupDetails?id=${g.id}`}>
                          <img
                            src={g.coverPhoto || defaultGroupCoverPhoto}
                            alt={g.name}
                            className="group-cover-photo"
                          />
                          <span className="group-Name">{g.name}</span>
                        </Link>
                        <button
                          className="group-btns"
                          onClick={() => handleJoinGroup(g.id)}
                        >
                          Join group
                        </button>
                      </div>
                    ))}
                  </>
                )}
              </>
            ) : (
              <p>No groups found</p>
            )}
          </div>
        );
      case "people":
        return (
          <div className="recommendations">
            <h2>People</h2>
            {searchResults.users.length > 0 ? (
              searchResults.users.map((u) => (
                <div key={u.id} className="recommendation user">
                  <Link to={`/userProfile/${u.id}`}>
                    <img
                      src={u.profilePicture || defaultProfilePicture}
                      alt={`${u.firstName} ${u.lastName}`}
                      className="recommendation-pic"
                    />
                    <span>{`${u.firstName} ${u.lastName}`}</span>
                  </Link>
                  {u.id !== user.id && (
                    <>
                      {!isFriend(u.id) && !hasSentFriendRequest(u.id) && (
                        <button onClick={() => sendFriendRequest(u.id)}>
                          Add friend
                        </button>
                      )}
                      {hasSentFriendRequest(u.id) && (
                        <button onClick={() => cancelFriendRequest(u.id)}>
                          Cancel request
                        </button>
                      )}
                    </>
                  )}
                </div>
              ))
            ) : (
              <p>No users found</p>
            )}
          </div>
        );
      case "groups":
        return (
          <div className="recomend">
            <h2>Groups</h2>
            {hasGroups ? (
              <>
                {hasJoinedGroups && (
                  <>
                    {joinedGroups.map((g) => (
                      <div key={g.id} className="group-card">
                        <img
                          src={g.coverPhoto || defaultGroupCoverPhoto}
                          alt={g.name}
                          className="group-cover-photo"
                        />
                        <span className="group-Name">{g.name}</span>
                        <button
                          className="view-btn"
                          onClick={() => navigateToGroup(g)}
                        >
                          View group
                        </button>
                      </div>
                    ))}
                  </>
                )}
                {hasFilteredGroups && (
                  <>
                    {filteredUnjoinedGroups.map((g) => (
                      <div key={g.id} className="group-card">
                        <Link to={`/GroupDetails?id=${g.id}`}>
                          <img
                            src={g.coverPhoto || defaultGroupCoverPhoto}
                            alt={g.name}
                            className="group-cover-photo"
                          />
                          <span className="group-Name">{g.name}</span>
                        </Link>
                        <button
                          className="group-btns"
                          onClick={() => handleJoinGroup(g.id)}
                        >
                          Join group
                        </button>
                      </div>
                    ))}
                  </>
                )}
              </>
            ) : (
              <p>No groups found</p>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <>
      <div className="header">
        <i className="fab fa-facebook"></i>
        <form onSubmit={handleSearch}>
          <div className="search-container">
            <i className="fas fa-search search-icon"></i>
            <input
              type="search"
              className="search-bar"
              placeholder="Search Facebook"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </form>
        <div className="links">
          <Link className="nav-item" to="/home">
            <i className="i fa-solid fa-house"></i>
            <span className="tooltip-text">Home</span>
          </Link>
          <Link className="nav-item" to="/friends">
            <i className="i fa-solid fa-user-group"></i>
            <span className="tooltip-text">Friends</span>
          </Link>
          <Link className="nav-item" to="/videos">
            <i className="i fa-brands fa-youtube"></i>
            <span className="tooltip-text">Videos</span>
          </Link>
          <Link className="nav-item" to="/groups">
            <i className="i fa-solid fa-users"></i>
            <span className="grp-txt tooltip-text">Groups</span>
          </Link>
        </div>
        <div className="user-info">
          <Link to="/user" id="link">
            <img
              src={user.profilePicture || defaultProfilePicture}
              alt="Profile"
              className="profile-pic"
            />
          </Link>
          <span className="user-name">
            {user.firstName} {user.lastName}
          </span>
        </div>
      </div>
      <div className="search-results">
        <div className="search-tabs">
          <button
            className={`tab-button ${activeTab === "all" ? "active" : ""}`}
            onClick={() => setActiveTab("all")}
          >
            All
          </button>
          <button
            className={`tab-button ${activeTab === "people" ? "active" : ""}`}
            onClick={() => setActiveTab("people")}
          >
            People
          </button>
          <button
            className={`tab-button ${activeTab === "groups" ? "active" : ""}`}
            onClick={() => setActiveTab("groups")}
          >
            Groups
          </button>
        </div>
        {renderContent()}
      </div>
    </>
  );
}
