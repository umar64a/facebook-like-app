import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import "./Login.css";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();

    if (!email || !password) {
      setErrorMessage("Please enter both email and password.");
      return;
    }

    const existingUsers = JSON.parse(localStorage.getItem("users")) || [];

    const foundUser = existingUsers.find(
      (user) => user.email === email && user.password === password
    );

    if (foundUser) {
      localStorage.setItem("user", JSON.stringify(foundUser));
      navigate("/home");
    } else {
      setErrorMessage("Incorrect email or password. Please try again.");
    }
  };

  return (
    <div className="container">
      <div>
        <h1 id="facebook">Facebook</h1>
        <p>
          Facebook helps you connect and share
          <br /> with the people in your life.
        </p>
      </div>
      <div className="form">
        <form onSubmit={handleLogin}>
          <input
            type="email"
            placeholder="Email address or phone number"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="form-control"
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="form-control"
          />
          <button type="submit" className="btn btn-primary">
            Login
          </button>
        </form>
        <Link>Forgot password?</Link>
        <hr id="hr" />
        <Link to="/signup" className="btn btn-secondary">
          Create New Account
        </Link>
        {errorMessage && <div className="error-message">{errorMessage}</div>}
      </div>
    </div>
  );
}
