import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";
import { useNavigate } from "react-router-dom";

import { useLocation } from "react-router-dom";

import "./UserGroup.css";

const defaultProfilePicture = "https://via.placeholder.com/150";
const defaultGroupCoverPhoto = "https://via.placeholder.com/600x200";

export default function UserGroup() {
  const [user, setUser] = useState({});
  const [group, setGroup] = useState({});
  const [activeTab, setActiveTab] = useState("discussion");
  const [coverPhotoChanged, setCoverPhotoChanged] = useState(false);
  const [discussionPosts, setDiscussionPosts] = useState([]);
  const [postContent, setPostContent] = useState("");
  const [postMedia, setPostMedia] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalField, setModalField] = useState("");
  const [modalData, setModalData] = useState({});
  const fileInputRef = useRef(null);
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const groupId = queryParams.get("id");
  const [allGroups, setAllGroups] = useState([]);
  const [activeMediaTab, setActiveMediaTab] = useState("photos");
  const [members, setMembers] = useState([]);
  const [userDetails, setUserDetails] = useState({});
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [friendRequests, setFriendRequests] = useState([]);
  const [friends, setFriends] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();
  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user")) || {};
    const groups = JSON.parse(localStorage.getItem("allGroups")) || [];

    const selectedGroup =
      groups.find((group) => group.id === parseInt(groupId, 10)) || {};

    const storedPosts =
      JSON.parse(localStorage.getItem(`discussionPosts_${groupId}`)) || [];
    setDiscussionPosts(storedPosts);
    const allStoredUsers = JSON.parse(localStorage.getItem("users")) || [];
    const storedFriends = JSON.parse(localStorage.getItem("friends")) || {};
    const storedRequests =
      JSON.parse(localStorage.getItem("friendRequests")) || [];
    setFriends(storedFriends[storedUser.id] || []);
    setFriendRequests(storedRequests);
    setAllGroups(groups);
    setGroup(selectedGroup);
    setLoggedInUser(storedUser);

    setUser(storedUser);
    const memberDetails = {};
    (selectedGroup.members || []).forEach((memberId) => {
      const userDetail = allStoredUsers.find((user) => user.id === memberId);
      if (userDetail) {
        memberDetails[memberId] = userDetail;
      }
    });
    const creatorId = selectedGroup.creatorId;
    if (creatorId) {
      const creatorDetail = allStoredUsers.find(
        (user) => user.id === creatorId
      );
      if (creatorDetail) {
        memberDetails[creatorId] = creatorDetail;
      }
    }
    setMembers(selectedGroup.members || []);
    setUserDetails(memberDetails);
  }, [groupId]);

  const handlePostSubmit = (e) => {
    e.preventDefault();
    if (!postContent && !postMedia) return;

    const newPost = {
      id: Date.now(),
      groupId: group.id,
      authorEmail: user.email,
      author: `${user.firstName} ${user.lastName}`,
      profilePicture: user.profilePicture || defaultProfilePicture,
      content: postContent,
      media: postMedia,
      likes: [],
    };

    const updatedPosts = [newPost, ...discussionPosts];
    setDiscussionPosts(updatedPosts);
    localStorage.setItem(
      `discussionPosts_${group.id}`,
      JSON.stringify(updatedPosts)
    );
    setPostContent("");
    setPostMedia(null);
    const input = document.getElementById("post-media-input");
    if (input) {
      input.value = "";
    }
  };

  const handleModalSave = () => {
    if (modalData[modalField]) {
      const updatedGroup = { ...group, [modalField]: modalData[modalField] };
      setGroup(updatedGroup);
      const updatedGroups = allGroups.map((g) =>
        g.id === group.id ? updatedGroup : g
      );
      localStorage.setItem("allGroups", JSON.stringify(updatedGroups));
      setIsModalOpen(false);
    }
  };

  const handleCoverPhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const newCoverPhoto = reader.result;
        setCoverPhotoChanged(true);
        setGroup({ ...group, coverPhoto: newCoverPhoto });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveClick = () => {
    if (coverPhotoChanged) {
      const updatedGroup = { ...group, coverPhoto: group.coverPhoto };
      setGroup(updatedGroup);

      const updatedGroups = allGroups.map((g) =>
        g.id === group.id ? updatedGroup : g
      );
      localStorage.setItem("allGroups", JSON.stringify(updatedGroups));
      setCoverPhotoChanged(false);

      addPhotoToDiscussion(group.coverPhoto);
    }
  };

  const addPhotoToDiscussion = (photo) => {
    const post = {
      id: Date.now(),
      groupId: group.id,
      content: "Cover Photo Updated",
      image: photo,
      authorEmail: user.email,
      author: `${user.firstName} ${user.lastName}`,
      profilePicture: user.profilePicture || defaultProfilePicture,
    };

    const updatedPosts = [post, ...discussionPosts];
    setDiscussionPosts(updatedPosts);
    localStorage.setItem(
      `discussionPosts_${group.id}`,
      JSON.stringify(updatedPosts)
    );
  };

  const handleMediaUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      setPostMedia(reader.result);
    };
    if (file) {
      reader.readAsDataURL(file);
    }
  };

  const handleLikeToggle = (postId) => {
    const updatedPosts = discussionPosts.map((post) => {
      if (post.id === postId) {
        const likesArray = Array.isArray(post.likes) ? post.likes : [];
        const alreadyLiked = likesArray.includes(user.email);

        return {
          ...post,
          likes: alreadyLiked
            ? likesArray.filter((email) => email !== user.email)
            : [...likesArray, user.email],
        };
      }
      return post;
    });

    setDiscussionPosts(updatedPosts);
    localStorage.setItem(
      `discussionPosts_${group.id}`,
      JSON.stringify(updatedPosts)
    );
  };

  const handleDeletePost = (id) => {
    const updatedPosts = discussionPosts.filter((post) => post.id !== id);
    setDiscussionPosts(updatedPosts);
    localStorage.setItem(
      `discussionPosts_${group.id}`,
      JSON.stringify(updatedPosts)
    );
  };
  const handleEditClick = (field) => {
    setModalField(field);
    setModalData({ [field]: group[field] });
    setIsModalOpen(true);
  };
  const handleDeleteField = (field) => {
    const updatedGroup = { ...group, [field]: "" };
    setGroup(updatedGroup);

    const existingGroups = JSON.parse(localStorage.getItem("allGroups")) || [];
    const updatedGroups = existingGroups.map((g) =>
      g.email === updatedGroup.email ? updatedGroup : g
    );

    localStorage.setItem("allGroups", JSON.stringify(updatedGroups));
    localStorage.setItem("group", JSON.stringify(updatedGroup));
  };
  const handleModalChange = (e) => {
    const { name, value } = e.target;
    setModalData({ ...modalData, [name]: value });
  };

  const sendFriendRequest = (id) => {
    const selectedUser = userDetails[id];
    if (!selectedUser) return;
    const newRequest = {
      id: uuidv4(),
      senderId: user.id,
      senderName: `${user.firstName} ${user.lastName}`,
      senderProfilePicture: user.profilePicture || defaultProfilePicture,
      receiverId: selectedUser.id,
    };

    const updatedRequests = [...friendRequests, newRequest];
    setFriendRequests(updatedRequests);
    localStorage.setItem("friendRequests", JSON.stringify(updatedRequests));
  };

  const cancelFriendRequest = (id) => {
    const updatedRequests = friendRequests.filter(
      (request) => !(request.receiverId === id && request.senderId === user.id)
    );
    setFriendRequests(updatedRequests);
    localStorage.setItem("friendRequests", JSON.stringify(updatedRequests));
  };

  const handleSearch = (e) => {
    e.preventDefault();
    navigate(`/search?term=${encodeURIComponent(searchTerm)}`);
  };
  const renderMediaTabContent = () => {
    const photoPosts = discussionPosts.filter(
      (post) => post.media && post.media.startsWith("data:image")
    );
    const videoPosts = discussionPosts.filter(
      (post) => post.media && post.media.startsWith("data:video")
    );

    const allPhotos = [
      group.coverPhoto,
      ...photoPosts.map((post) => post.media),
    ];

    switch (activeMediaTab) {
      case "photos":
        return (
          <div className="photo-grid">
            {allPhotos.length > 0 ? (
              allPhotos.map((photo, index) =>
                photo ? (
                  <img
                    key={index}
                    src={photo}
                    alt={`${index}`}
                    className="photo-item"
                  />
                ) : null
              )
            ) : (
              <p>No photos available.</p>
            )}
          </div>
        );
      case "videos":
        return (
          <div className="photo-grid">
            {videoPosts.length > 0 ? (
              videoPosts.map((post) => (
                <video
                  key={post.id}
                  controls
                  src={post.media}
                  alt="Post media"
                  className="photo-item"
                ></video>
              ))
            ) : (
              <p>No videos available.</p>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "discussion":
        return (
          <div className="posts">
            <div className="create-post">
              <form onSubmit={handlePostSubmit}>
                <textarea
                  placeholder="What's on your mind?"
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                ></textarea>
                <hr />
                <label htmlFor="post-media-input" className="post-upload">
                  <i className="fa-solid fa-images"></i>Photo/Video
                </label>
                <input
                  type="file"
                  accept="image/*, video/*"
                  onChange={handleMediaUpload}
                  id="post-media-input"
                  style={{ display: "none" }}
                />
                <button
                  id="post-btn"
                  type="submit"
                  style={{
                    display: postContent || postMedia ? "block" : "none",
                  }}
                >
                  Post
                </button>
              </form>
            </div>
            {discussionPosts.map((post) => (
              <div key={post.id} className="post">
                <div className="post-header">
                  <img
                    src={post.profilePicture || defaultProfilePicture}
                    alt="Author"
                    className="profile-picture"
                  />
                  <span className="span">{post.author}</span>
                  {post.authorEmail === user.email && (
                    <button
                      className="delete-button"
                      onClick={() => handleDeletePost(post.id)}
                    >
                      <i className="fa-solid fa-xmark"></i>
                    </button>
                  )}
                </div>
                <p className="content">{post.content}</p>
                {post.image && (
                  <div className="post-media-container">
                    <img src={post.image} alt="Post" className="post-media" />
                  </div>
                )}
                {post.media && (
                  <div className="post-media-container">
                    {post.media.startsWith("data:image") ? (
                      <img
                        src={post.media}
                        alt="Post media"
                        className="post-media"
                      />
                    ) : (
                      <video
                        controls
                        src={post.media}
                        alt="Post media"
                        className="post-media"
                      ></video>
                    )}
                  </div>
                )}
                <div className="post-actions">
                  <hr />
                  <button
                    onClick={() => handleLikeToggle(post.id)}
                    className={
                      Array.isArray(post.likes) &&
                      post.likes.includes(user.email)
                        ? "liked"
                        : ""
                    }
                  >
                    <i className="fa-solid fa-thumbs-up"></i>
                    {Array.isArray(post.likes) &&
                    post.likes.includes(user.email)
                      ? "Unlike"
                      : "Like"}{" "}
                    {Array.isArray(post.likes) ? post.likes.length : 0}
                  </button>
                </div>
              </div>
            ))}
          </div>
        );
      case "members":
        return (
          <div className="members-list">
            <h2>Members</h2>
            {members.length ? (
              members.map((memberId) => {
                const member = userDetails[memberId];
                if (!member) return null;

                const isCurrentUser = member.id === loggedInUser.id;
                const isFriend = friends.some(
                  (friend) => friend.id === memberId
                );
                const hasSentRequest = friendRequests.some(
                  (req) =>
                    req.senderId === loggedInUser.id &&
                    req.receiverId === memberId
                );

                return (
                  <div key={memberId} className="member">
                    <Link
                      to={isCurrentUser ? "/user" : `/userProfile/${member.id}`}
                    >
                      <img
                        src={member.profilePicture || defaultProfilePicture}
                        alt={`${member.firstName}'s profile`}
                        className="friend-profile-pic"
                      />
                      <span>
                        {member.firstName} {member.lastName}
                      </span>
                    </Link>
                    {!isCurrentUser &&
                      (hasSentRequest ? (
                        <button
                          className="cancel-btn"
                          onClick={() => cancelFriendRequest(memberId)}
                        >
                          <i className="fas fa-user-xmark"></i>
                          Cancel request
                        </button>
                      ) : !isFriend ? (
                        <button
                          className="add-btn"
                          onClick={() => sendFriendRequest(memberId)}
                        >
                          <i class="fas fa-user-plus"></i>
                          Add friend
                        </button>
                      ) : null)}
                  </div>
                );
              })
            ) : (
              <p>No members yet.</p>
            )}
            {userDetails[group.creatorId] && (
              <div className="">
                <img
                  src={
                    userDetails[group.creatorId]?.profilePicture ||
                    defaultProfilePicture
                  }
                  alt="Creator"
                  className="friend-profile-pic"
                />
                <span>
                  {userDetails[group.creatorId]?.firstName}{" "}
                  {userDetails[group.creatorId]?.lastName}
                </span>
              </div>
            )}
          </div>
        );

      case "about":
        return (
          <div className="group-about">
            <h2>About</h2>
            <div className="field">
              <p>
                <strong>Description:</strong>
                <br />
                <span>{group.description}</span>
              </p>
              <div className="btns">
                {group.description && (
                  <button onClick={() => handleDeleteField("description")}>
                    <i className="del fa-solid fa-trash"></i>
                  </button>
                )}
                <button onClick={() => handleEditClick("description")}>
                  <i className="pen fa-solid fa-pen"></i>
                </button>
              </div>
            </div>
            <div className="field">
              <p>
                <strong>Location:</strong>
                <br />
                <span>{group.location}</span>
              </p>
              <div className="btns">
                {group.location && (
                  <button onClick={() => handleDeleteField("location")}>
                    <i className="del fa-solid fa-trash"></i>
                  </button>
                )}
                <button onClick={() => handleEditClick("location")}>
                  <i className="pen fa-solid fa-pen"></i>
                </button>
              </div>
            </div>
            <div className="field">
              <p>
                <strong>History:</strong>
                <br />
                <span>{group.history}</span>
              </p>
              <div className="btns">
                {group.history && (
                  <button onClick={() => handleDeleteField("history")}>
                    <i className="del fa-solid fa-trash"></i>
                  </button>
                )}
                <button onClick={() => handleEditClick("history")}>
                  <i className="pen fa-solid fa-pen"></i>
                </button>
              </div>
            </div>
          </div>
        );
      case "media":
        return (
          <div className="media">
            <h2>Media</h2>
            <div className="media-tabs">
              <button onClick={() => setActiveMediaTab("photos")}>
                Photos
              </button>
              <button onClick={() => setActiveMediaTab("videos")}>
                Videos
              </button>
            </div>
            {renderMediaTabContent()}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <>
      <div className="header">
        <i className="fab fa-facebook"></i>
        <form onSubmit={handleSearch}>
          <div className="search-container">
            <i className="fas fa-search search-icon"></i>
            <input
              type="search"
              className="search-bar"
              placeholder="Search Facebook"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </form>
        <div className="links">
          <Link className="nav-item" to="/home">
            <i className="i fa-solid fa-house"></i>
            <span className="tooltip-text">Home</span>
          </Link>
          <Link className="nav-item" to="/friends">
            <i className="i fa-solid fa-user-group"></i>
            <span className="tooltip-text">Friends</span>
          </Link>
          <Link className="nav-item" to="/videos">
            <i className="i fa-brands fa-youtube"></i>
            <span className="tooltip-text">Videos</span>
          </Link>
          <Link className="nav-item" to="/groups">
            <i className="i fa-solid fa-users"></i>
            <span className="grp-txt tooltip-text">Groups</span>
          </Link>
        </div>
        <div className="user-info">
          <Link to="/user" id="link">
            <img
              src={user.profilePicture || defaultProfilePicture}
              alt="Profile"
              className="profile-pic"
            />
          </Link>
          <span className="user-name">
            {user.firstName} {user.lastName}
          </span>
        </div>
      </div>
      <div className="groupsection">
        <div className="group-info">
          <img
            src={group.coverPhoto || defaultGroupCoverPhoto}
            alt="Group Cover"
            className="cover-photo"
          />
          <button
            className="cover-edit"
            onClick={() => fileInputRef.current.click()}
          >
            <i className="fa-solid fa-pen"></i>Edit
          </button>
          <input
            type="file"
            accept="image/*"
            onChange={handleCoverPhotoChange}
            ref={fileInputRef}
            style={{ display: "none" }}
          />
          {coverPhotoChanged && (
            <button onClick={handleSaveClick} id="save">
              Save
            </button>
          )}
          <div className="group-owner">
            <h2 className="group-name">{group.name}</h2>
            <Link to="/user" id="link">
              <img
                src={user.profilePicture || defaultProfilePicture}
                alt="Owner Profile"
                className="profile-pic"
              />
            </Link>
          </div>
        </div>

        <hr />
        <div className="tabs">
          <button onClick={() => setActiveTab("discussion")}>Discussion</button>
          <button onClick={() => setActiveTab("members")}>Members</button>
          <button onClick={() => setActiveTab("about")}>About</button>
          <button onClick={() => setActiveTab("media")}>Media</button>
        </div>
        {renderTabContent()}
      </div>
      {isModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <h2>
              Edit {modalField.charAt(0).toUpperCase() + modalField.slice(1)}
            </h2>
            <input
              type="text"
              name={modalField}
              value={modalData[modalField] || ""}
              onChange={handleModalChange}
            />
            <button onClick={handleModalSave} disabled={!modalData[modalField]}>
              Save
            </button>
            <button onClick={() => setIsModalOpen(false)}>Cancel</button>
          </div>
        </div>
      )}
    </>
  );
}
